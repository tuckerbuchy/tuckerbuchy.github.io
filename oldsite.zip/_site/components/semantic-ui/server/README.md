# Semantic Docs

## How to Use

This folder contains the templates used to generate the static website for Semantic UI

To create the docs yourself, run the commands in the top-level directory:

```
npm install -g docpad
docpad install eco;
docpad update; docpad upgrade;
```

This node project uses docpad to generate the static documentation files for Semantic UI.


